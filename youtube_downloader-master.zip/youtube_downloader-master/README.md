# youtube_downloader

Project sederhana Youtube Downloader dengan Flutter.

Referensi API oleh [AkuAri](https://api.akuari.my.id/).

# Screenshot
<p align="center">
  <img src="assets/images/Screenshot_20220409-090926.jpg" width="350" title="hover text">
  <img src="assets/images/Screenshot_20220409-091052.jpg" width="350" alt="accessibility text">
</p>

<!-- ![Screenshot1](assets/images/Screenshot_20220409-090926.jpg)
![Screenshot2](assets/images/Screenshot_20220409-091052.jpg) -->
