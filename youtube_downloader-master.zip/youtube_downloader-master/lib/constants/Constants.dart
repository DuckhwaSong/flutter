class Constants {
  static const url = "https://api.akuari.my.id/downloader/yt1?link=";
}
