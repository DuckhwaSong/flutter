// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'GetMedataDataYoutube.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GetMedataDataYoutube _$GetMedataDataYoutubeFromJson(Map<String, dynamic> json) {
  return GetMedataDataYoutube(
    title: json['title'] as String,
    result: json['result'] as String,
    quality: json['quality'] as String,
    size: json['size'] as String,
    thumbb: json['thumbb'] as String,
  );
}

Map<String, dynamic> _$GetMedataDataYoutubeToJson(
        GetMedataDataYoutube instance) =>
    <String, dynamic>{
      'title': instance.title,
      'result': instance.result,
      'quality': instance.quality,
      'size': instance.size,
      'thumbb': instance.thumbb,
    };
